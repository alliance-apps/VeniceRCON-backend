module.exports = {
  apps : [{
    name: "vurcon",
    script: "npm",
    args: "start",
    watch: false,
    autorestart: true
  }]
}